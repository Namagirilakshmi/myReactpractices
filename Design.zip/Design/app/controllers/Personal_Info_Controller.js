app.controller('Personal_Info_Controller',function($scope,$location,personal_Info_service,$http,$window,$localStorage){
	
		personal_Info_service.loadState_City(function(success){
			if(success){
				$scope.city_state=personal_Info_service.city_state;
				console.log($scope.city_state);
			}
		});	
		$scope.show_sugg=false;
		$http.get('assets/data/address.json')
				.success(function(data) {
				    $scope.addr_sugg=data;
				    		    			 
				  });
				$scope.validDate=false;
		
		$scope.choices = [{id: 'choice1','pattern1':/^[0-9]{3}$/,'pattern2':/^[0-9]{3}$/,'pattern3':/^[0-9]{4}$/,'cell':false }];

		var sessionData=JSON.parse($window.sessionStorage.getItem("personal_Info_data"));

		var BasicsessionData=JSON.parse($window.sessionStorage.getItem("Basic_Info_data"));
		if(BasicsessionData){

		}
		else{
			$location.path("/");
		}
		$scope.checkvalidDate=function(){
			taskDate=$scope.month+"-"+$scope.day+"-"+$scope.year;
			console.log(taskDate);
			 if($scope.day != '' && $scope.month!='' && $scope.year!=''){
                customDate = new Date(taskDate);
                console.log(customDate);
                isValid = !isNaN(customDate);

                if(isValid){
                    console.log('Valid');
                    $scope.validDate=false;
                }
                else{
                    console.log('Invalid');
                   $scope.validDate=true;
                }
            }
           
            
		}

		$scope.personal_Info={
			fields:{
				fname:'',
				lname:'',
				addr1:'',
				addr2:'',
				state:'',
				city:'',
				phone:[],
				cell:[],
				pincode:'',	
				longstay:'',			
				email:'',
				dob:'',
				socialSecurity:''
			},
			pattern:{
				name:/^[a-zA-Z ]{1,25}$/,																
				pincode:/^[0-9]{6}$/,
				phone1:/^[0-9]{3}$/,
				phone2:/^[0-9]{3}$/,
				phone3:/^[0-9]{4}$/,
				cellphone:/^[0-9]{5}$/,
				email:/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i,
				socialSecurity:/^[0-9]{4}$/
			},		 
			validate:function(form){				
					for (var i = 0; i < $scope.choices.length; i++) {						
						var telephone=''+$scope.choices[i].tel1+''+$scope.choices[i].tel2+''+$scope.choices[i].tel3;						
						this.fields.phone.push(telephone);	
						this.fields.cell.push($scope.choices[i].cell);												
					}		

					var dob=$scope.month+' '+$scope.day+','+$scope.year;			
					var socialSecurity=$scope.social1+$scope.social2+$scope.social3;						
					this.fields.dob=dob;
					this.fields.socialSecurity=socialSecurity;

					var edit_count_over=false;					
					var Edit_count=JSON.parse($window.sessionStorage.getItem("personalInfo_count"));
					console.log(Edit_count,typeof(Edit_count));
					if (Edit_count!=null) {
						console.log(Edit_count,typeof(Edit_count));
						if(Edit_count<=3){
							var c=Edit_count;
							c++;
							$window.sessionStorage.setItem("personalInfo_count",c);	
						}
						else{
							alert("You can edit only 3 times");
							edit_count_over=true;
							$location.path('/Account_Details');	
						}
					}
					else{
						var c=1;
						$window.sessionStorage.setItem("personalInfo_count",JSON.stringify(c));
					}
					if(!edit_count_over){
							personal_Info_service.validateForm(this.fields);	
					}
					$location.path('/Account_Details');						
									
			},
			getSuggestion:function(){
				
				$scope.show_sugg=true;
				$http.get('assets/data/address.json')
				.success(function(data) {
				    $scope.addr_sugg=data;
				    		    			 
				  });
				
				
			},
			close_sugg:function(){
				$scope.show_sugg=false;
			},
			select_address:function(address){
				this.fields.addr1=address;
			},
			loadCity:function(){
				var state=this.fields.state;
				var jsonobj=$scope.city_state;
				var keys=Object.keys(jsonobj);
				for(var index=0;index<keys.length;index++){
					if(state==keys[index])
					{
						$scope.city=jsonobj[keys[index]];

					}				
				}
			},
			cellphone:function(checked,phoneCount){
				
				if(checked){
					phoneCount.pattern1=/^(\+91)$/;
					phoneCount.pattern2=/^[0-9]{5}$/;
					phoneCount.pattern3=/^[0-9]{5}$/;
				}
				else{
					phoneCount.pattern1=/^[0-9]{3}$/;
					phoneCount.pattern2=/^[0-9]{3}$/;
					phoneCount.pattern3=/^[0-9]{4}$/;
				}
			},
			checkValidPhone:function(phone,pattern,ch){
				
				if(pattern.test(phone))
				{										
					ch.shoPattern=false;
				}
				else{
					ch.shoPattern=true;
				}
				
			},
			addNewChoice:function() {
		    var newItemNo = $scope.choices.length+1;
		    $scope.choices.push({'id':'choice'+newItemNo,'pattern1':/^[0-9]{3}$/,'pattern2':/^[0-9]{3}$/,'pattern3':/^[0-9]{4}$/,'cell':false});
		  	},
		  	removeChoice:function(select) {
			    var lastItem = $scope.choices.length-1;
			    if(lastItem!=0){
			    	$scope.choices.splice(lastItem);
			    }
			    else
			    {
			    	alert("Should add atleast one Phone Number");
			    	return false;
			    	$location.path("/Personal_Info");
			    }
			    
			   			    			    
		  	},
		  	loadBasicInfo:function(){		  		
		  		$location.path('/');
		  	},
		  	loadAccountDetails:function(){
				$location.path('/Account_Details');
			}
					
		};
		if(sessionData){
			console.log(sessionData);
			$scope.personal_Info.fields.fname=sessionData.fname;
			$scope.personal_Info.fields.lname=sessionData.lname;
			$scope.personal_Info.fields.addr1=sessionData.addr1;
			$scope.personal_Info.fields.addr2=sessionData.addr2;
			$scope.personal_Info.fields.state=sessionData.state;
			
			personal_Info_service.loadState_City(function(success){
				if(success){
					var allload=personal_Info_service.city_state;					
					var keys=Object.keys(allload);
					for(var index=0;index<keys.length;index++){
							if(sessionData.state==keys[index])
							{
								$scope.city=allload[keys[index]];							
							}				
						}
						
					}
			});	
			
			$scope.personal_Info.fields.city=sessionData.city;


			var ph=sessionData.phone;
			var part1=ph[0].substring(0,3);
			var part2=ph[0].substring(3,6);
			var part3=ph[0].substring(6,10);
			var celll=sessionData.cell;
			
			console.log(ph);
			
				
				$scope.choices[0].tel1=part1;
				$scope.choices[0].tel2=part2;
				$scope.choices[0].tel3=part3;
				$scope.choices[0].cell=celll[0];

				for (var i = 1; i < ph.length; i++) {
					var part1=ph[i].substring(0,3);
					var part2=ph[i].substring(3,6);
					var part3=ph[i].substring(6,10);
					var newItemNo = $scope.choices.length+1;
					$scope.choices.push({'id':'choice'+newItemNo,'pattern1':/^[0-9]{3}$/,'pattern2':/^[0-9]{3}$/,'pattern3':/^[0-9]{4}$/,'cell':celll[i],'tel1':part1,'tel2':part2,'tel3':part3});
					$scope.choices[i].tel1=part1;
					$scope.choices[i].tel2=part2;
					$scope.choices[i].tel3=part3;
					$scope.choices[i].cell=celll[i];
				}
			
			
			
			$scope.personal_Info.fields.pincode=sessionData.pincode;
			$scope.personal_Info.fields.longstay=sessionData.longstay;
			$scope.personal_Info.fields.email=sessionData.email;

			var socialSecurity=sessionData.socialSecurity;
			if(socialSecurity!=null){
			$scope.social1=socialSecurity.substring(0,4);
			$scope.social2=socialSecurity.substring(4,8);
			$scope.social3=socialSecurity.substring(8,12);	
			}	
		}
		$scope.goBack=function(){
		window.history.back();
	}

});