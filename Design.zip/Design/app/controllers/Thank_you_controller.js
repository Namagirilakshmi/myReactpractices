app.controller('Thank_you_Controller',function($scope,$location,$rootScope,$window)
{
	console.log($window.sessionStorage.getItem("data"));
	$scope.loadBasicInfo=function(){
		$location.path('/');
	}
	$scope.loadPersonalInfo=function(){
		$location.path('/Personal_Info');
	}
	$scope.loadAccountDetails=function(){
				$location.path('/Account_Details');
			}

			
});