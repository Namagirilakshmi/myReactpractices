app.controller('Account_Details_Controller',function($scope,$http,$location,$rootScope,$window,$route)
{

	var sessionData=JSON.parse($window.sessionStorage.getItem("Account_Details"));
	$http.get("assets/data/data.json").success(function(data) {
 		
      	$scope.secQues1 = data;
      	/*console.log($scope.secQues1);*/
      	});
	$http.get("assets/data/data1.json").success(function(data) {
 		
      	$scope.secQues2 = data;
      	/*console.log($scope.secQues1);*/
      	});
	$scope.check_btn=true;
	var myPix = new Array("assets/images/0.jpg","assets/images/1.jpg","assets/images/2.jpg","assets/images/3.jpg","assets/images/4.jpg");
	/*$scope.init=myPix[0];
	url=$scope.init.substring(14,15);*/
	var randomNum = Math.floor(Math.random() * myPix.length);
	$scope.src=myPix[randomNum];
	url=$scope.src.substring(14,15);	
	
	$scope.changeCaptcha=function(){
		
		var randomNum = Math.floor(Math.random() * myPix.length);
		 $scope.src=myPix[randomNum];
		 url=$scope.src.substring(14,15);		
	}
	$scope.fields={
		fname:'',
		password1:'',
		password2:'',
		pin1:'',
		pin2:'',
		promo:'',
		secQue1:'',
		secAns1:'',
		secQue2:'',
		secAns2:'',
		captcha:''
		
	};
	if(sessionData){
		$scope.fields.fname=sessionData.fname;
		$scope.fields.password1=sessionData.password1;
		$scope.fields.password2=sessionData.password2;
		$scope.fields.pin1=sessionData.pin1;
		$scope.fields.pin2=sessionData.pin2;	
		$scope.fields.promo=sessionData.promo;	
		
		$scope.fields.secQue1=sessionData.secQue1;
		$scope.fields.secAns1=sessionData.secAns1;
		$scope.fields.secQue2=sessionData.secQue2;	
		$scope.fields.secAns2=sessionData.secAns2;

		$scope.check_btn=false;
		$scope.sessionDataSet=true;
		
		
	}
	else{
		$scope.sessionDataSet=false;
	}
	var BasicsessionData=JSON.parse($window.sessionStorage.getItem("Basic_Info_data"));
	var PersonalsessionData=JSON.parse($window.sessionStorage.getItem("personal_Info_data"));
		if(BasicsessionData){

		}
		else{
			$location.path("/");
		}
		if (PersonalsessionData) {}
			else{
				$location.path("/Personal_Info");
			}
	
	$scope.loadBasicInfo=function(){
		$location.path('/');
	}
	$scope.loadPersonalInfo=function(){
		$location.path('/Personal_Info');
	}
	$scope.checkUsername=function()
	{
		var check=JSON.parse($window.localStorage.getItem("uname"));
		var user=$scope.fields.fname;
		var flag=0;
		if(check)
		{
		for(var i=0;i<check.length;i++)
		{
			if(user==check[i])
			{

				alert("UserName already Taken Choose Another Name!!");
				$scope.fields.fname=" ";
				flag=1;
			}
			

		}
		
	}
	if(flag==0)
		{
			alert("Available!");
			$scope.check_btn=false;
		}
	}
	$scope.saveDetails=function(){

		var text=$scope.fields.captcha;
		var correctCaptacha=0;
		if(url==0)
		{
			
			if(text=="F9bRX")
			{				
				correctCaptacha=1;
			}
			else
			{
				alert("invalid captcha");
				$route.reload();

			}
		}
		else if(url==1)
		{
			
			if(text=="smwm")
			{
				
				correctCaptacha=1;
			}
			else
			{
				alert("invalid captcha");
				$route.reload();
			}
		}
		else if(url==2)
		{
			if(text=="RBSKW")
			{
				
				correctCaptacha=1;
			}
			else
			{
				alert("invalid captcha");
				$route.reload();
			}
		}
		else if(url==3)
		{
			if(text=="BZkvaau")
			{
				
				correctCaptacha=1;
			}
			else
			{
				alert("invalid captcha");
				$route.reload();
			}
		}
		else if(url==4)
		{
			if(text=="spatular")
			{				
				correctCaptacha=1;
			}
			else
			{
				alert("invalid captcha");
				$route.reload();
			}
		}

		if(correctCaptacha){			
			
			if($scope.check_btn){
				console.log("btn true");
				
			}
			else{
					var edit_count_over=false;
					console.log("available storing");
					var Edit_count=JSON.parse($window.sessionStorage.getItem("account_count"));
					console.log(Edit_count,typeof(Edit_count));
						if (Edit_count!=null) {
							console.log(Edit_count,typeof(Edit_count));
							if(Edit_count<=3){
								var c=Edit_count;
								c++;
								$window.sessionStorage.setItem("account_count",c);	
							}
							else{
								alert("You can edit only 3 times");
								edit_count_over=true;
								$location.path("/Thank_You");
							}
						}
						else{
							var c=1;
							$window.sessionStorage.setItem("account_count",JSON.stringify(c));
						}
						if(!edit_count_over){
								$window.sessionStorage.setItem("Account_Details", JSON.stringify($scope.fields));	
						}
							
						
							var check=JSON.parse($window.localStorage.getItem("uname"));
							var flag=0;
							if(check)
							{
								for (var i = 0; i < check.length; i++) {
									if(check[i]==$scope.fields.fname){
										flag=1;
										break;
									}
								}
								if(flag==0){
									check.push($scope.fields.fname);
									$window.localStorage.setItem("uname",JSON.stringify(check));
								}						
							}
							else
							{
									var uname1=[];
									uname1.push($scope.fields.fname);
									$window.localStorage.setItem("uname",JSON.stringify(uname1));
							}
						
						$location.path('/Thank_You');
				}
				
			
		}
		
	}
	$scope.pattern_fname=/^[a-zA-Z]{1}[a-zA-Z0-9]{5,11}$/;
	$scope.password=/^[a-zA-Z]{1}[a-zA-Z0-9]{5,11}$/;
	$scope.pin=/^[0-9]{4}$/;
	$scope.promo=/^[A-Z]{3}[0-9]{2}$/;
	$scope.goBack=function(){
		window.history.back();
	}
	

});