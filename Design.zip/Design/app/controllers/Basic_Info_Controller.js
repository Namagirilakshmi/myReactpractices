app.controller('Basic_Info_Controller',function($scope,$route,$location,Basic_Info_Service,$window){
	var sessionData=JSON.parse($window.sessionStorage.getItem("Basic_Info_data"));
	$scope.fields={
		fname:'',
		lname:'',
		email:'',
		ph:'',		
		zip:'',
		chk:''
	};

	if(sessionData){
		console.log(sessionData);
		$scope.fields.fname=sessionData.fname;
		$scope.fields.lname=sessionData.lname;
		$scope.fields.email=sessionData.email;		
		
		var ph=sessionData.ph;
		$scope.ph1=ph.substring(0,3);
		$scope.ph2=ph.substring(3,6);
		$scope.ph3=ph.substring(6,10);

		$scope.fields.zip=sessionData.zip;				
	}
	
	$scope.pattern_fname=/^[a-zA-Z]{1,25}$/;
	$scope.emailPattern=/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
	$scope.phone1=/^[0-9]{3}$/;
	$scope.phone3=/^[0-9]{4}$/;
	$scope.zip=/^[0-9]{6}$/;
	$scope.saveDetails=function(){
		
		var telephone=$scope.ph1+""+$scope.ph2+""+$scope.ph3;
		$scope.fields.ph=telephone;
		
		



					var edit_count_over=false;					
					var Edit_count=JSON.parse($window.sessionStorage.getItem("BasicInfo_count"));
					console.log(Edit_count,typeof(Edit_count));
					if (Edit_count!=null) {
						console.log(Edit_count,typeof(Edit_count));
						if(Edit_count<=3){
							var c=Edit_count;
							c++;
							$window.sessionStorage.setItem("BasicInfo_count",c);	
						}
						else{
							alert("You can edit only 3 times");
							edit_count_over=true;
							$location.path('/Personal_Info');
						}
					}
					else{
						var c=1;
						$window.sessionStorage.setItem("BasicInfo_count",JSON.stringify(c));
					}
					if(!edit_count_over){
							Basic_Info_Service.saveDetails($scope.fields);	
					}
					$location.path('/Personal_Info');
						
						
				
		
	}
	$scope.loadPersonalInfo=function(){
		$location.path('/Personal_Info');
	}
	$scope.loadAccountDetails=function(){
		$location.path('/Account_Details');
	}

	$scope.resetFunc=function(){
		$route.reload();
	}
		

});
