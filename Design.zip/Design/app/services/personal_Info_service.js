app.factory('personal_Info_service',function($http,$rootScope,$window){
	personal_Info_service={};
	
	personal_Info_service.validateForm=function(fields){
			
		/*window.localStorage.set("", JSON.stringify(myObj));	*/		
		$rootScope.AllData.push(fields);
		$window.sessionStorage.setItem("personal_Info_data", JSON.stringify(fields));
		
		
	}
	personal_Info_service.loadState_City=function(cb){
		$http.get('assets/data/state_city.json')
		.success(function(data) {
		    personal_Info_service.city_state = data;
		    cb(true);
		    return;			    			 
		  });
		cb(false);
		return;
	}
	return personal_Info_service;
});