app.factory('Basic_Info_Service',function($rootScope,$window){
	
	Basic_Info_Service={};

	Basic_Info_Service.saveDetails=function(data){
		$rootScope.AllData.push(data);

		$window.sessionStorage.setItem("Basic_Info_data", JSON.stringify(data));
		
		
		
		console.log($rootScope.AllData);
	};


	return Basic_Info_Service;
})