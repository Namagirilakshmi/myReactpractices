app.directive('myDirective',['$timeout',myDirective]);
function myDirective($timeout){
	return {
		restrict:'A',
		require:'ngModel',
		scope:{
			minValue : '=',
			maxValue : '='
		},
		link:function(scope,element,attr,ctrl){
			var minval=angular.isDefined(scope.minValue) ? (scope.maxValue) :0;
			var maxval=angular.isDefined(scope.maxValue) ? (scope.minValue) :0;

			function customValidator(input){
				if(input<scope.minValue || input>scope.maxValue){
					alert("Wrong");
				}else{
					alert("Right");
				}
			}
			element.on('blur',function(){
				$timeout(function(){
					customValidator(ctrl.$viewValue);
				},1000)
			})
		}
	}
}