var app=angular.module('myApp',["ngRoute","ngStorage"]);

app.run(function($rootScope) {
    $rootScope.AllData = [count=0];
})