app.filter('myFilter',function(){
	return function(input){
		var inputNum = input % 10;
		if(isNaN(input)){
			return false;
		}
			else{
				if(inputNum ===1){
					return input + 'st';
				}else if(inputNum === 2){
					return input + 'nd';
				}else if(inputNum === 3){
					return input + 'rd';
				}else{
					return input + 'th';
				}
			}		
		}
});