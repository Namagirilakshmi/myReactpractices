app.config(['$routeProvider',function($routeProvider){
	$routeProvider	
	.when('/Personal_Info',{
		templateUrl:"partials/Personal_Info.html",
		controller:"Personal_Info_Controller"
		
	})
	.when('/',{
		templateUrl:"partials/Basic_Info.html",
		controller:"Basic_Info_Controller"
		
	})
	.when('/Account_Details',{
		templateUrl:"partials/Account_Details.html",
		controller:"Account_Details_Controller"
		
	})
	.when('/Thank_You',{
		templateUrl:"partials/Thank_you.html",
		controller:"Thank_you_Controller"		
		
	})

	.otherwise({
		redirectTo:'/'
	});
}]);