module FontAwesome
  module Sass
    VERSION = '4.7.0'
  end
end
