/**
 * Created by Mohan Rathour on 19/06/17.
 */
/**
 * Constant properties
 * @type {string}
 */
export const RESOURCE_URL = "http://localhost:8888/api/restaurant",
             ITEM_DATA = "Item_Data",
             ORDER_DATA = "Order_Data",
             SEARCH_DATA = "Search_Data";
